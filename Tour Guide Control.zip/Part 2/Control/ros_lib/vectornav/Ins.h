#ifndef _ROS_vectornav_Ins_h
#define _ROS_vectornav_Ins_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace vectornav
{

  class Ins : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef float _time_type;
      _time_type time;
      typedef uint16_t _week_type;
      _week_type week;
      typedef uint64_t _utcTime_type;
      _utcTime_type utcTime;
      typedef uint16_t _insStatus_type;
      _insStatus_type insStatus;
      typedef float _yaw_type;
      _yaw_type yaw;
      typedef float _pitch_type;
      _pitch_type pitch;
      typedef float _roll_type;
      _roll_type roll;
      typedef float _latitude_type;
      _latitude_type latitude;
      typedef float _longitude_type;
      _longitude_type longitude;
      typedef float _altitude_type;
      _altitude_type altitude;
      typedef float _nedVelX_type;
      _nedVelX_type nedVelX;
      typedef float _nedVelY_type;
      _nedVelY_type nedVelY;
      typedef float _nedVelZ_type;
      _nedVelZ_type nedVelZ;
      float attUncertainty[3];
      typedef float _posUncertainty_type;
      _posUncertainty_type posUncertainty;
      typedef float _velUncertainty_type;
      _velUncertainty_type velUncertainty;

    Ins():
      header(),
      time(0),
      week(0),
      utcTime(0),
      insStatus(0),
      yaw(0),
      pitch(0),
      roll(0),
      latitude(0),
      longitude(0),
      altitude(0),
      nedVelX(0),
      nedVelY(0),
      nedVelZ(0),
      attUncertainty(),
      posUncertainty(0),
      velUncertainty(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      offset += serializeAvrFloat64(outbuffer + offset, this->time);
      *(outbuffer + offset + 0) = (this->week >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->week >> (8 * 1)) & 0xFF;
      offset += sizeof(this->week);
      *(outbuffer + offset + 0) = (this->utcTime >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->utcTime >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->utcTime >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->utcTime >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (this->utcTime >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (this->utcTime >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (this->utcTime >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (this->utcTime >> (8 * 7)) & 0xFF;
      offset += sizeof(this->utcTime);
      *(outbuffer + offset + 0) = (this->insStatus >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->insStatus >> (8 * 1)) & 0xFF;
      offset += sizeof(this->insStatus);
      union {
        float real;
        uint32_t base;
      } u_yaw;
      u_yaw.real = this->yaw;
      *(outbuffer + offset + 0) = (u_yaw.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_yaw.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_yaw.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_yaw.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->yaw);
      union {
        float real;
        uint32_t base;
      } u_pitch;
      u_pitch.real = this->pitch;
      *(outbuffer + offset + 0) = (u_pitch.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_pitch.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_pitch.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_pitch.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->pitch);
      union {
        float real;
        uint32_t base;
      } u_roll;
      u_roll.real = this->roll;
      *(outbuffer + offset + 0) = (u_roll.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_roll.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_roll.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_roll.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->roll);
      offset += serializeAvrFloat64(outbuffer + offset, this->latitude);
      offset += serializeAvrFloat64(outbuffer + offset, this->longitude);
      offset += serializeAvrFloat64(outbuffer + offset, this->altitude);
      union {
        float real;
        uint32_t base;
      } u_nedVelX;
      u_nedVelX.real = this->nedVelX;
      *(outbuffer + offset + 0) = (u_nedVelX.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_nedVelX.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_nedVelX.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_nedVelX.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->nedVelX);
      union {
        float real;
        uint32_t base;
      } u_nedVelY;
      u_nedVelY.real = this->nedVelY;
      *(outbuffer + offset + 0) = (u_nedVelY.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_nedVelY.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_nedVelY.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_nedVelY.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->nedVelY);
      union {
        float real;
        uint32_t base;
      } u_nedVelZ;
      u_nedVelZ.real = this->nedVelZ;
      *(outbuffer + offset + 0) = (u_nedVelZ.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_nedVelZ.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_nedVelZ.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_nedVelZ.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->nedVelZ);
      for( uint32_t i = 0; i < 3; i++){
      union {
        float real;
        uint32_t base;
      } u_attUncertaintyi;
      u_attUncertaintyi.real = this->attUncertainty[i];
      *(outbuffer + offset + 0) = (u_attUncertaintyi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_attUncertaintyi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_attUncertaintyi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_attUncertaintyi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->attUncertainty[i]);
      }
      union {
        float real;
        uint32_t base;
      } u_posUncertainty;
      u_posUncertainty.real = this->posUncertainty;
      *(outbuffer + offset + 0) = (u_posUncertainty.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_posUncertainty.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_posUncertainty.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_posUncertainty.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->posUncertainty);
      union {
        float real;
        uint32_t base;
      } u_velUncertainty;
      u_velUncertainty.real = this->velUncertainty;
      *(outbuffer + offset + 0) = (u_velUncertainty.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_velUncertainty.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_velUncertainty.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_velUncertainty.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->velUncertainty);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->time));
      this->week =  ((uint16_t) (*(inbuffer + offset)));
      this->week |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->week);
      this->utcTime =  ((uint64_t) (*(inbuffer + offset)));
      this->utcTime |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->utcTime |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->utcTime |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->utcTime |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      this->utcTime |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      this->utcTime |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      this->utcTime |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      offset += sizeof(this->utcTime);
      this->insStatus =  ((uint16_t) (*(inbuffer + offset)));
      this->insStatus |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->insStatus);
      union {
        float real;
        uint32_t base;
      } u_yaw;
      u_yaw.base = 0;
      u_yaw.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_yaw.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_yaw.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_yaw.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->yaw = u_yaw.real;
      offset += sizeof(this->yaw);
      union {
        float real;
        uint32_t base;
      } u_pitch;
      u_pitch.base = 0;
      u_pitch.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_pitch.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_pitch.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_pitch.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->pitch = u_pitch.real;
      offset += sizeof(this->pitch);
      union {
        float real;
        uint32_t base;
      } u_roll;
      u_roll.base = 0;
      u_roll.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_roll.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_roll.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_roll.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->roll = u_roll.real;
      offset += sizeof(this->roll);
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->latitude));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->longitude));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->altitude));
      union {
        float real;
        uint32_t base;
      } u_nedVelX;
      u_nedVelX.base = 0;
      u_nedVelX.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_nedVelX.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_nedVelX.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_nedVelX.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->nedVelX = u_nedVelX.real;
      offset += sizeof(this->nedVelX);
      union {
        float real;
        uint32_t base;
      } u_nedVelY;
      u_nedVelY.base = 0;
      u_nedVelY.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_nedVelY.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_nedVelY.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_nedVelY.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->nedVelY = u_nedVelY.real;
      offset += sizeof(this->nedVelY);
      union {
        float real;
        uint32_t base;
      } u_nedVelZ;
      u_nedVelZ.base = 0;
      u_nedVelZ.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_nedVelZ.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_nedVelZ.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_nedVelZ.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->nedVelZ = u_nedVelZ.real;
      offset += sizeof(this->nedVelZ);
      for( uint32_t i = 0; i < 3; i++){
      union {
        float real;
        uint32_t base;
      } u_attUncertaintyi;
      u_attUncertaintyi.base = 0;
      u_attUncertaintyi.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_attUncertaintyi.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_attUncertaintyi.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_attUncertaintyi.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->attUncertainty[i] = u_attUncertaintyi.real;
      offset += sizeof(this->attUncertainty[i]);
      }
      union {
        float real;
        uint32_t base;
      } u_posUncertainty;
      u_posUncertainty.base = 0;
      u_posUncertainty.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_posUncertainty.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_posUncertainty.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_posUncertainty.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->posUncertainty = u_posUncertainty.real;
      offset += sizeof(this->posUncertainty);
      union {
        float real;
        uint32_t base;
      } u_velUncertainty;
      u_velUncertainty.base = 0;
      u_velUncertainty.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_velUncertainty.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_velUncertainty.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_velUncertainty.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->velUncertainty = u_velUncertainty.real;
      offset += sizeof(this->velUncertainty);
     return offset;
    }

    const char * getType(){ return "vectornav/Ins"; };
    const char * getMD5(){ return "f15f75d40252c44bbfc42358abc151e2"; };

  };

}
#endif
