# SimpleTimer for Arduino

This is a fork of the SimpleTimer library from Marcello Romani (http://playground.arduino.cc/Code/SimpleTimer). Sadly there is no original repository to apply pull requests.

## Additional Features

* Support lambda-expressions / std::function callbacks
